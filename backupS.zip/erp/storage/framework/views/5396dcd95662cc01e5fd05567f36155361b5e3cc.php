<div class="modal fade" id="modalempresaeditar" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-dark">Nueva Empresa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form autocomplete="off" method="POST" action="<?php echo e(route('registrar_e')); ?>"
                    class="card-body cardbody-color p-5">
                    <?php echo csrf_field(); ?>
                    <div class="row m-3 mt-0">
                        <div class="col-sm-3">
                            <label class="h5">Nombre:</label>
                        </div>
                        <div class="col-sm-5">
                            <input required type="text" class="form-control" id="nombre" name="nombre">
                        </div>
                    </div>
                    <div class="row m-3">
                        <div class="col-sm-3">
                            <label class="h5">NIT:</label>
                        </div>
                        <div class="col-sm-5">
                            <input required maxlength="2"
                                oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"
                                type="text" class="form-control" id="nit" name="nit">
                        </div>
                    </div>
                    <div class="row m-3">
                        <div class="col">
                            <label class="h5">Sigla:</label>
                        </div>
                        <div class="col">
                            <input required type="text" class="form-control" id="sigla" name="sigla">
                        </div>
                        <div class="col">
                            <label class="h5">Telefono:</label>
                        </div>
                        <div class="col">
                            <input required type="number" class="form-control" id="telefono" name="telefono">
                        </div>
                    </div>
                    <div class="row m-3">
                        <div class="col">
                            <label class="h5">Correo:</label>
                        </div>
                        <div class="col">
                            <input required type="text" class="form-control" id="correo" name="correo">
                        </div>
                        <div class="col">
                            <label class="h5">Niveles:</label>
                        </div>
                        <div class="col">
                            <select type="text" class="form-select" id="niveles" name="niveles">
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                            </select>
                        </div>
                    </div>
                    <div class="row m-3">
                        <div class="col-sm-3">
                            <label class="h5">Dirección:</label>
                        </div>
                        <div class="col-sm-7">
                            <textarea required class="form-control" name="direccion" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <button onclick="validarDatos()" type="submit" class="btn btn-primary">Grabar</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/silvaerp/public_html/erp/resources/views/editar-empresa.blade.php ENDPATH**/ ?>