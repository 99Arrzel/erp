<script>
    let editarEmpresa = () => {
        let editar = '<?php echo e(route('editEmpresa')); ?>';
        let crear = '<?php echo e(route('registrar_e')); ?>';
        let url = '';
        if ($('#btnEmpresa').html() == "Editar") {
            url = editar;
        } else {
            url = crear;
        }
        $.ajax({
            type: "POST",
            url: url,
            data: {
                id_empresa: $('#nom-empresa').val(),
                nombre: $('#nombre').val(),
                nit: $('#nit').val(),
                sigla: $('#sigla').val(),
                correo: $('#correo').val(),
                niveles: $('#niveles').val(),
                direccion: $('#direccion').val(),
                telefono: $('#telefono').val(),
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(data) {
                if (data.success == true) {
                    if ($('#btnEmpresa').html() == "Crear") {
                        Swal.fire({
                            icon: 'success',
                            title: 'Empresa Creada',
                            text: 'La empresa se ha creado correctamente',
                            type: 'success',
                        }).then(function() {
                            location.reload();
                        });
                    } else {
                        Swal.fire({
                            icon: 'success',
                            title: 'Empresa Editada',
                            text: 'La empresa se ha editado correctamente',
                            type: 'success',
                        }).then(function() {
                            location.reload();
                        });
                    }
                }
            },
            error: function(data) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: data.responseJSON.message
                });
            }
        });
    };

    /* ANTIGUO EDITAR/CREAR 
    	let antioguoeditar = () => {
    			if ($('#btnEmpresa').html() == "Editar") {
    					$.ajax({
    							type: "POST",
    							url: "<?php echo e(route('editEmpresa')); ?>",
    							data: {
    									id_empresa: $('#nom-empresa').val(),
    									nombre: $('#nombre').val(),
    									nit: $('#nit').val(),
    									sigla: $('#sigla').val(),
    									correo: $('#correo').val(),
    									niveles: $('#niveles').val(),
    									direccion: $('#direccion').val(),
    									telefono: $('#telefono').val(),
    									_token: '<?php echo e(csrf_token()); ?>'
    							},
    							success: function(response) {
    									Swal.fire({
    											icon: 'success',
    											title: 'Éxito',
    											text: 'Se ha editado la empresa correctamente.',
    									}).then(function() {
    											location.reload();
    									});
    									console.log(response);
    							},
    							error: function(response) {
    									Swal.fire({
    											icon: 'error',
    											title: 'Error',
    											text: response.responseJSON.message
    									});
    							}
    					});
    			} else {
    					$.ajax({
    							type: "POST",
    							url: "<?php echo e(route('registrar_e')); ?>",
    							data: {
    									nombre: $('#nombre').val(),
    									nit: $('#nit').val(),
    									sigla: $('#sigla').val(),
    									correo: $('#correo').val(),
    									niveles: $('#niveles').val(),
    									direccion: $('#direccion').val(),
    									telefono: $('#telefono').val(),
    									_token: '<?php echo e(csrf_token()); ?>'
    							},
    							success: function(response) {
    									Swal.fire({
    											icon: 'success',
    											title: 'Éxito',
    											text: 'Se ha creado la empresa correctamente.',
    									});
    									console.log(response);
    							},
    							error: function(response) {
    									Swal.fire({
    											icon: 'error',
    											title: 'Error',
    											text: response.responseJSON.message
    									});
    							}
    					});
    			}
    	}
    */

    function seleccionarCrear() {
        $('#btnEmpresa').removeClass('btn-warning').addClass('btn-primary');
        $('#btnEmpresa').html("Crear");
        $('#titleModalEmpresa').text("Crear empresa");
        $('#nombre').val("");
        $('#nit').val("");
        $('#sigla').val("");
        $('#correo').val("");
        $('#telefono').val("");
        $('#direccion').val("");
        $('#btnEmpresa').removeAttr("type").attr("type", "button")
    }

    function seleccionarEditar() {
        $('#btnEmpresa').removeAttr("type").attr("type", "button"); //Que no haga nadazanga
        $('#btnEmpresa').html("Editar");
        $('#btnEmpresa').removeClass('btn-primary').addClass('btn-warning');
        $('#titleModalEmpresa').text("Editando empresa");
        $.ajax({
            type: "POST",
            url: "<?php echo e(route('getData_e')); ?>",
            data: {
                id_empresa: $('#nom-empresa').val(),
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {
                $('#nombre').val(response.nombre);
                $('#nit').val(response.nit);
                $('#sigla').val(response.sigla);
                $('#correo').val(response.correo);
                $('#telefono').val(response.telefono);
                $('#niveles').val(response.niveles);
                $('#direccion').val(response.direccion);

            }
        });
    }
</script>
<?php /**PATH /home/silvaerp/public_html/erp/resources/views/validacion-empresa.blade.php ENDPATH**/ ?>