<div class="modal fade" id="modalperiodo" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-s">
      <div class="modal-content">
          <div class="modal-header">
              <h5 id="titleModalPeriodo" class="modal-title text-dark">Nuevo Periodo</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
              <form autocomplete="off" method="POST" action="<?php echo e(route('registrar_e')); ?>"
                  class="card-body cardbody-color p-5">
                  <?php echo csrf_field(); ?>
                  <div class="row m-3 mt-0">
                      <div class="col-sm-3">
                          <label class="h5">Nombre:</label>
                      </div>
                      <div class="col-sm-8 ms-4">
                          <input required type="text"
                              oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"
                              onkeypress="return /[A-Z ]/i.test(event.key)" maxlength="15" class="form-control"
                              id="nombre" name="nombre">
                      </div>
                  </div>
                  <div class="row m-3 mt-0">
                      <div class="col-sm-3">
                          <label class="h5">Fecha Inicio:</label>
                      </div>
                      <div class="col-sm-8 ms-4">
                        <input required type="date" class="form-control" id="fecha_inicio" name="fecha_inicio">
                      </div>
                  </div>
                  <div class="row m-3 mt-0">
                      <div class="col-sm-3">
                          <label class="h5">Fecha Fin:</label>
                      </div>
                      <div class="col-sm-8 ms-4">
                        <input required type="date" class="form-control" id="fecha_fin" name="fecha_fin">
                      </div>
                  </div>
                  <div class="row mt-3 ms-3">
                      <div class="col">
                          <button id="btnPeriodo" type="submit" class="btn btn-primary">Grabar</button>
                      </div>
                  </div>
              </form>
          </div>
          <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cerrar</button>
          </div>
      </div>
  </div>
</div>
<?php /**PATH /home/silvaerp/public_html/erp/resources/views/registro-periodo.blade.php ENDPATH**/ ?>