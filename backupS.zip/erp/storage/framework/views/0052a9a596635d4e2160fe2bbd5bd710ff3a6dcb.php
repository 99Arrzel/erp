<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <h2 class="text-center text-dark mt-5">Seleccione una Empresa</h2>
                <div class="card my-3">
                    <form method="POST" action="" class="card-body cardbody-color p-5">
                        <?php echo csrf_field(); ?>
                        <div class="row m-3">
                            <div class="mb-2 col">
                                <label class="h5">Empresa:</label>
                            </div>
                            <div class="text-center col">
                                <select class="form-select" id="nom-empresa">
                                    <?php $__currentLoopData = $data->empresas ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($empresa->id_empresa); ?>"><?php echo e($empresa->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="row m-3">
                            <div class="col">
                                <button type="button" class="btn btn-primary form-control"
                                    onclick="redireccionar()">Ingresar</button>
                            </div>
                            <div class="col">
                                <button type="button" class="btn btn-success form-control" data-bs-toggle="modal"
                                    onclick="seleccionarCrear()" data-bs-target="#modalempresa">Nueva Empresa</button>
                            </div>
                        </div>
                        <div class="row m-3">
                            <div class="col">
                                <button type="button" class="btn btn-primary form-control" data-bs-toggle="modal"
                                    data-bs-target="#modalempresa" onclick="seleccionarEditar()">Editar</button>
                            </div>
                            <div class="col">
                                <button type="button" class="btn btn-outline-danger form-control">Eliminar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('registro-empresa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <style>
        .btn-color {
            background-color: #0e1c36;
            color: #fff;
        }

        .cardbody-color {
            background-color: #ebf2fa;
        }

        a {
            text-decoration: none;
        }

    </style>
    <?php echo $__env->make('validacion-empresa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <script>
        let redireccionar = () => {
            let sel = document.getElementById("nom-empresa");
            let text = sel.options[sel.selectedIndex].text;
            window.location.replace("https://queeserp.tk/lista/" + text + "/");
        };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/silvaerp/public_html/erp/resources/views/seleccion-empresa.blade.php ENDPATH**/ ?>