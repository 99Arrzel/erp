<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ErpTruco</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>

<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('datatables/datatables.css')); ?>" />
<script type="text/javascript" src="<?php echo e(asset('datatables/datatables.js')); ?>" defer></script>
<script src="<?php echo e(asset('dayjs/dayjs.min.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>

</html>
<?php /**PATH /home/silvaerp/public_html/erp/resources/views/layouts/app.blade.php ENDPATH**/ ?>