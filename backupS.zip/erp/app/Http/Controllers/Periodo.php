<?php

namespace App\Http\Controllers;

use App\Models\Periodo as ModelsPeriodo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Yajra\DataTables\Facades\DataTables;

class Periodo extends Controller
{
    public function create(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string|max:20|min:3',
            'fecha_inicio' => 'required|date',
            'fecha_fin' => 'required|date|after:fecha_inicio'
        ]);
        $nueva_gestion = ModelsPeriodo::create([
            'nombre' => $request->nombre,
            'fecha_inicio' => $request->fecha_inicio,
            'fecha_fin' => $request->fecha_fin,
            'id_usuario' => Auth::user()->id_usuario,
            'id_gestion' => $request->id_gestion,
            'estado' => 1
        ]);
    }
    public function getPeriodoDeGestion(Request $request)
    {
        $request->validate([
            'id_gestion' => 'required|integer'
        ]);
        //Validar usuario
        $gestion = ModelsPeriodo::where('id_gestion', $request->id_gestion)->where('id_usuario', Auth::user()->id_usuario)->get();

        return DataTables::of($gestion)->make(true);
    }
}