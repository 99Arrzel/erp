//Agarrar id de la empresa. 👍
$("#nom-empresa").val();